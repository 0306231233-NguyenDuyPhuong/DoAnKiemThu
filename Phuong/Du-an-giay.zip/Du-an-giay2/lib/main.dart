import 'package:coffee_shop_test/ui/screens/home/home.dart';
import 'package:coffee_shop_test/ui/screens/login/login_view.dart';
import 'package:flutter/material.dart';
void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home:LoginView()
    );
  }
}
