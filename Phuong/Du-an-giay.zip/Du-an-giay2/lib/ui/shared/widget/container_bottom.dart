import 'package:coffee_shop_test/ui/screens/user/user.dart';
import 'package:coffee_shop_test/ui/screens/wishlist/wishlist_screen.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import '../../screens/home/widgets/TBottomNavigation.dart';
import '../../screens/home/home.dart';
class ContainerBottom extends StatefulWidget {
  final String token;
  final userData;
  const ContainerBottom({super.key, required this.token, this.userData});

  @override
  State<ContainerBottom> createState() => _ContainerBottomState();
}

class _ContainerBottomState extends State<ContainerBottom> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80,
      decoration: BoxDecoration(color: Colors.white),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Tbottomnavigation(
            height: 80,
            width: 80,
            color: Colors.white,
            icon: Icon(Iconsax.home, size: 30,fontWeight: FontWeight.bold, color: Colors.black87),
            title: "Home",
            handler: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Home(token:widget.token,)),
              );
            },
          ),
          Tbottomnavigation(
            height: 80,
            width: 80,
            color: Colors.white,
            icon: Icon(Iconsax.shop, size: 35, color: Colors.black),
            title: "Store",
          ),
          Tbottomnavigation(
            height: 80,
            width: 80,
            color: Colors.white,
            icon: Icon(Iconsax.heart, size: 35, color: Colors.black),
            title: "Wishlist",
            handler: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) =>WishlistScreen(token:widget.token, user_id: 0,)),
              );
            },
          ),
          Tbottomnavigation(
            height: 80,
            width: 80,
            color: Colors.white,
            icon: Icon(Iconsax.user, size: 35, color: Colors.black),
            title: "Profile",
            handler: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) =>UserScreen(token:widget.token, userData: null,)),
              );
            },
          ),
        ],
      ),
    );
  }
}
