import 'package:flutter/material.dart';
import 'package:coffee_shop_test/ui/shared/widget/my_text.dart';
import '../widget/my_image.dart';

class TListCategory extends StatefulWidget {
  final categoryData;
  const TListCategory({super.key, required this.categoryData});
  @override
  State<TListCategory> createState() => _TListCategoryState();
}

class _TListCategoryState extends State<TListCategory> {

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: widget.categoryData!["data"].length,
        itemBuilder: (context, index) {
          final item = widget.categoryData!["data"][index];
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              children: [
                GestureDetector(
                  child: Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: MyImage(
                        width: 50,
                        height: 50,
                        url: item["image"],
                      ),
                    ),
                  ),
                  onTap: () {
                    setState(() {

                    });
                  },
                ),
              ],
            ),
          );;
        },
      );
  }
}
/**/