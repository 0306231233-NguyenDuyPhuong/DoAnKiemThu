import 'package:coffee_shop_test/data/viewmodels/order_viewmodels.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import 'package:intl/intl.dart';

String formatDate(String dateString) {
  final date = DateTime.parse(dateString);
  return DateFormat('dd/MM/yyyy').format(date);
}

class OrderView extends StatefulWidget {
  final String token;
  const OrderView({super.key, required this.token});

  @override
  State<OrderView> createState() => _OrderViewState();
}

class _OrderViewState extends State<OrderView> {
  final listStatusOrder = ["","Pending", "Processing","Shipped","Delivered","Cancelled","Refunded","Failed"];
  late Future<Map<String, dynamic>> _fetchData;
  OrderViewModel orderViewModel = OrderViewModel();
  Future<Map<String, dynamic>> loadOrder()async{
    final result = await Future.wait([
      orderViewModel.getOrders(widget.token)
    ]);
    return {
      'orders':result[0]
    };
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _fetchData = loadOrder();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Orders", style: const TextStyle(fontSize: 25, color: Colors.black, fontWeight: FontWeight.bold),),
      ),
      body: FutureBuilder(future: _fetchData, builder: (context, snapshot){
        switch(snapshot.connectionState) {
          case ConnectionState.none:
            // TODO: Handle this case.
            throw UnimplementedError();
          case ConnectionState.waiting:
            return Center(
              child: CircularProgressIndicator(),
            );
          case ConnectionState.active:
            // TODO: Handle this case.
            throw UnimplementedError();
          case ConnectionState.done:
            if(snapshot.hasError){
              return Center(
                child: Text("${snapshot.error}"),
              );
            }
            final orders = snapshot.data!["orders"]['orders'];
            return ListView.builder(
                itemCount: orders["data"].length,
                itemBuilder: (context, index){
                  final item = orders["data"][index];

                  //final date = DateTime(item["updated_at"]);
                  //final formatted = DateFormat('dd/MM/yyyy').format(date);

                  return Container(
                    height: 170,
                    width: 300,
                    padding: EdgeInsets.all(20),
                    margin: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12)
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Icon(Iconsax.ship,size: 30, fontWeight: FontWeight.bold,),
                                const SizedBox(width: 10,),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("${listStatusOrder[item["status"]]}", style: const TextStyle(fontSize: 20, color: Colors.blueAccent, fontWeight: FontWeight.bold),),
                                    Text(formatDate(item["updated_at"]), style: const TextStyle(fontSize: 25, color: Colors.black87, fontWeight: FontWeight.bold),),
                                  ],
                                )
                              ],
                            ),
                            IconButton(onPressed: (){},
                                icon: Icon(Iconsax.arrow_right_3, size: 20, fontWeight: FontWeight.bold,))
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Icon(Iconsax.tag, color: Colors.black87, size: 30,fontWeight: FontWeight.bold,),
                                const SizedBox(width: 10,),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("Order", style: const TextStyle(fontSize: 15, color: Colors.grey, fontWeight: FontWeight.bold),),
                                    Text("${item["id"]}", style: const TextStyle(fontSize: 20, color: Colors.black, fontWeight: FontWeight.bold),),
                                  ],
                                )
                              ],
                            ),
                            Row(
                              children: [
                                Icon(Iconsax.calendar, color: Colors.black87, size: 30,fontWeight: FontWeight.bold,),
                                const SizedBox(width: 10,),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("Shipping Date", style: const TextStyle(fontSize: 15, color: Colors.grey, fontWeight: FontWeight.bold),),
                                    Text(formatDate(item["updated_at"]), style: const TextStyle(fontSize: 20, color: Colors.black, fontWeight: FontWeight.bold),),
                                  ],
                                )
                              ],
                            ),

                          ],
                        )
                      ],
                    ),
                  );
            });
        }
      })
    );
  }
}
