import 'package:coffee_shop_test/ui/shared/widget/my_text.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

class OrderDetailView extends StatefulWidget {
  const OrderDetailView({super.key});

  @override
  State<OrderDetailView> createState() => _OrderDetailViewState();
}

class _OrderDetailViewState extends State<OrderDetailView> {
  int? seletedIndex = -1;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: MyText(title: "evaluate", size: 25, color: Colors.black87, fontWeight: FontWeight.bold,),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top: 20, left: 16, right: 16),
          child: Column(
            children: [
              MyText(title: "Evaluate customer", size: 30, color: Colors.black87, fontWeight: FontWeight.bold,),
              const SizedBox(height: 10,),
              SizedBox(
                height: 100,
                child: ListView.builder(
                    itemCount: 5,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index){
                  return IconButton(onPressed: (){
                    setState(() {
                      seletedIndex = index;
                    });
                  }, icon: (seletedIndex!>index-1)?Icon( Iconsax.star1, size: 60, color: Colors.yellow,):Icon( Iconsax.star, size: 60, color: Colors.grey,));
                }),
              ),
              Container(
                height: 150,
                width: 370,
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.grey,
                    width: 1.5
                  ),
                  borderRadius: BorderRadius.circular(12)
                ),
                child: TextField(
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Comment",
                    contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
