import 'dart:math';

import 'package:coffee_shop_test/data/models/user.dart';
import 'package:coffee_shop_test/data/viewmodels/user_viewmodels.dart';
import 'package:coffee_shop_test/ui/screens/user/user_screen.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import '../../shared/widget/Ttext.dart';
import '../../shared/widget/my_button.dart';
import '../../shared/widget/my_icon.dart';
import '../../shared/widget/my_text.dart';
import '../../shared/widget/my_textfield.dart';
import '../home/home_screen.dart';
import 'create_account_screen.dart';

class LoginView extends StatefulWidget {
  const LoginView({super.key});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final txtPhoneController = TextEditingController();
  final txtPasswordController = TextEditingController();
  final UserViewModel userViewModel = UserViewModel();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 50),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
             Image.asset(
              width: 180,
              height: 180,
              "assets/images/t-store-splash-logo-black.png",
            ),
            MyText(
              title: TText.TitleLogin,
              size: 30,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            MyText(
              title: TText.TitleLogin2,
              size: 15,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
            Center(
              child: Column(
                children: [
                  MyTextfield(
                    width: 400,
                    height: 20,
                    radius: 12,
                    labelTitle: "E-Mail",
                    iconLeft: Iconsax.direct_right,
                    iconRight: null,
                    fontWeight: FontWeight.bold,
                    size: 20,
                    color: Colors.black,
                    colorSize: Colors.black,
                    fillColor: Colors.white,
                    controller: txtPhoneController,
                  ),
                  MyTextfield(
                    width: 400,
                    height: 20,
                    radius: 12,
                    labelTitle: "Password",
                    iconLeft: Iconsax.password_check,
                    iconRight: Iconsax.eye,
                    fontWeight: FontWeight.bold,
                    size: 20,
                    color: Colors.black,
                    colorSize: Colors.black,
                    fillColor: Colors.white,
                    controller: txtPasswordController,
                  ),

                  MyButton(
                    radius: 12,
                    width: 380,
                    height: 60,
                    colorButton: Colors.blueAccent,
                    child: MyText(
                      title: "Sign In",
                      size: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    handler: () async{
                      txtPhoneController.text = "0352993348";
                      txtPasswordController.text = "abc@123%^&";
                      final user = User(id: 1, email: '', password: txtPasswordController.text, name: '', role: 1, avatar: '', phone: txtPhoneController.text, status: 1,  fullname: "", gender: false, birth: "");
                      UserViewModel userViewModel = UserViewModel();
                      final result = await userViewModel.userLogin(user);
                      final login = result["login"];
                      if(login["status"]==200){
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>HomeScreen(token: login["token"],)));
                      }else{
                        showDialog(context: context, builder: (context){
                          return AlertDialog(
                            title: Text("Đăng nhập thất bại"),
                          );
                        });
                      }
                    }
                  ),
                  MyButton(
                    radius: 12,
                    width: 380,
                    height: 60,
                    colorButton: Colors.white,
                    child: MyText(
                      title: "Create Account",
                      size: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                    handler: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>CreateAccount()));
                    },
                  ),

                  Padding(
                    padding: const EdgeInsets.only(top: 30, bottom: 40),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        MyText(
                          title: TText.TitleSig,
                          size: 15,
                          color: Colors.grey,
                        ),
                      ],
                    ),
                  ),

                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      MyIcon(
                        widthContainer: 60,
                        heightContainer: 60,
                        radius: 400,
                        child: Image.asset(
                          width: 30,
                          height: 30,
                          "assets/images/google-icon.png",
                        ),
                      ),
                      MyIcon(
                        widthContainer: 60,
                        heightContainer: 60,
                        radius: 400,
                        child: Image.asset(
                          width: 30,
                          height: 30,
                          "assets/images/facebook-icon.png",
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            //check box
          ],
        ),
      ),
    );
  }
}
