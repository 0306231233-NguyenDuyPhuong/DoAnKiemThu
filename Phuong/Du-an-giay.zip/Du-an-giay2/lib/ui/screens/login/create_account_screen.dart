import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import '../../shared/widget/Ttext.dart';
import '../../shared/widget/my_button.dart';
import '../../shared/widget/my_icon.dart';
import '../../shared/widget/my_text.dart';
import '../user/widgets/add_address_container.dart';

class CreateAccount extends StatefulWidget {
  const CreateAccount({super.key});

  @override
  State<CreateAccount> createState() => _CreateAccountState();
}

class _CreateAccountState extends State<CreateAccount> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 20, left: 16, bottom: 30),
            child: MyText(title: "Let's create your account", size: 25, color: Colors.black87, fontWeight: FontWeight.bold,),
          ),
          /*Row(
            children: [
              ContainerAddAddress(
                width: 190,
                icon: Icon(
                  Iconsax.user,
                  size: 25,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey,
                ),
                title: 'Street',
              ),
              ContainerAddAddress(
                width: 190,
                icon: Icon(
                  Iconsax.user,
                  size: 25,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey,
                ),
                title: 'Postal Code',
              ),
            ],
          ),
          ContainerAddAddress(
            width: 400,
            icon: Icon(
              Iconsax.user,
              size: 25,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
            title: 'Name',
          ),
          ContainerAddAddress(
            width: 400,
            icon: Icon(
              Iconsax.user,
              size: 25,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
            title: 'Phone Number',
          ),

          ContainerAddAddress(
            width: 400,
            icon: Icon(
              Iconsax.user,
              size: 25,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
            title: 'Country',
          ),ContainerAddAddress(
            width: 400,
            icon: Icon(
              Iconsax.user,
              size: 25,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
            title: 'Country',
          ),*/
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 16, top: 20),
            child: MyButton(
              radius: 12,
              width: 400,
              height: 60,
              colorButton: Colors.blueAccent,
              child: MyText(
                title: "Create Account",
                size: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              handler: () {},
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 30, bottom: 40),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                MyText(
                  title: TText.TitleSig,
                  size: 15,
                  color: Colors.grey,
                ),
              ],
            ),
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              MyIcon(
                widthContainer: 60,
                heightContainer: 60,
                radius: 400,
                child: Image.asset(
                  width: 30,
                  height: 30,
                  "assets/images/google-icon.png",
                ),
              ),

              MyIcon(
                widthContainer: 60,
                heightContainer: 60,
                radius: 400,
                child: Image.asset(
                  width: 30,
                  height: 30,
                  "assets/images/facebook-icon.png",
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
