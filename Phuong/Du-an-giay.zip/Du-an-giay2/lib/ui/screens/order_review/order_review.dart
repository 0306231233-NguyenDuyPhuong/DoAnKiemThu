import 'package:coffee_shop_test/data/viewmodels/cart_item_viewmodels.dart';
import 'package:coffee_shop_test/ui/screens/cart/list_cart_item.dart';
import 'package:coffee_shop_test/ui/screens/cart/widgets/list_cart_overview.dart';
import 'package:flutter/material.dart';
import '../../shared/widget/my_button.dart';
import '../../shared/widget/my_image.dart';
import '../../shared/widget/my_text.dart';
import '../cart/TContainerImage.dart';
import '../cart/TContainerName.dart';
import 'TRowPrice.dart';

class OrderReview extends StatefulWidget {
  final cartItem;
  final int user_id;
  final String token;
  final int subtatal;
  const OrderReview({super.key, required this.cartItem, required this.user_id, required this.token, required this.subtatal});

  @override
  State<OrderReview> createState() => _OrderReviewState();
}

class _OrderReviewState extends State<OrderReview> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: MyText(
          title: "Order review",
          size: 25,
          color: Colors.black,
          fontWeight: FontWeight.bold,
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            //List view
            Container(
              height: 250,
              child: ListCartOverview(cartItems: widget.cartItem, user_id: widget.user_id, token: widget.token, onChanged: (int p1) {  },),
            ),
            //Giảm gía
            Container(
              height: 80,
              width: 390,
              padding: EdgeInsets.only(left: 16, right: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.grey,
                  width: 1
                )
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 70,
                    width: 260,
                    margin: EdgeInsets.only(top: 14),
                    decoration: BoxDecoration(
                    ),
                    child: TextField(
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hint: Text("Have a promo code? Enter here", style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black54),)
                      ),
                    ),
                  ),
                  Container(
                    height: 60,
                    width: 80,
                    decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(12)
                    ),
                    child: Center(child: Text("Apply", style: const TextStyle(fontSize: 20, color: Colors.grey, fontWeight: FontWeight.bold),)),
                  ),
                ],
              )
            ),
            const SizedBox(height: 25),
            //Order
            Container(
              width: 390,
              padding: EdgeInsets.only(top: 10, left: 16, right: 16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(12),
                  topRight: Radius.circular(12),
                ),
                border: Border.all(
                  color: Colors.grey.withOpacity(0.3),
                  width: 2,
                ),
              ),
              child: Column(
                children: [
                  //price
                  TContainerPrice(subtatol: widget.subtatal,),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 20),
                    child: Container(width: 370, height: 2, color: Colors.grey),
                  ),
                  //payment
                  Column(
                    children: [
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          MyText(
                            title: "Payment Method",
                            size: 23,
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                          MyText(
                            title: "Change",
                            size: 15,
                            color: Colors.deepPurple,
                            fontWeight: FontWeight.bold,
                          ),
                        ],
                      ),
                      Container(
                        height: 100,
                        child: ListView.builder(
                          itemCount: 1,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 20),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                      left: 16,
                                      right: 16,
                                    ),
                                    child: Container(
                                      height: 60,
                                      width: 60,
                                      decoration: BoxDecoration(
                                        color: Colors.grey.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(400),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(5.0),
                                        child: Image.asset(
                                          width: 70,
                                          height: 70,
                                          "assets/images/logo_momo.png",
                                        ),
                                      ),
                                    ),
                                  ),
                                  MyText(title: "Momo", size: 20,fontWeight: FontWeight.bold, color: Colors.black87)
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                  //add ress
                  Column(
                    children: [
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          MyText(
                            title: "Shipping Address",
                            size: 23,
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                          MyText(
                            title: "Change",
                            size: 15,
                            color: Colors.deepPurple,
                            fontWeight: FontWeight.bold,
                          ),
                        ],
                      ),

                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
        child: MyButton(
          radius: 12,
          width: 290,
          height: 70,
          colorButton: Colors.blueAccent,
          child: MyText(
            title: "Checkout \$${widget.subtatal}",
            size: 17,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
          handler: () async{

            int user_id = widget.user_id;
            int pay_id = 1;
            int shipper_id = 1;
            String shipping_address = "HCM";
            int total = widget.subtatal;
            String note = "Nhẹ tay";

            CartItemViewmodels cartItemViewmodels = CartItemViewmodels();
            final result = await cartItemViewmodels.postCheckoutCart(widget.token, user_id, pay_id, shipper_id, shipping_address, total, note);
            setState(() {
              if(result["status"]==200){
                showDialog(context: context, builder: (context){
                  return AlertDialog(
                    title: Text("${result["message"]}"),
                    actions: [
                      ElevatedButton(onPressed: (){
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                      }, child: Text("Tiếp tục mua hàng"))
                    ],
                  );
                });

              }else{
                showDialog(context: context, builder: (context){
                  return AlertDialog(
                    title: Text("${result["message"]}"),
                  );
                });
              }
            });
          },
        ),
      ),
    );
  }
}