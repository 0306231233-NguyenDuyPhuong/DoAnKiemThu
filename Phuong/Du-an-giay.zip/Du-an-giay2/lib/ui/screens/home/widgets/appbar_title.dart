import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import '../../../shared/widget/my_text.dart';

class TTitle extends StatelessWidget {
  const TTitle({
    super.key, this.hanlder,
  });

  final Function()?hanlder;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 40, left: 16, right: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              MyText(title: "Good day for shopping", size: 16, color: Colors.grey),
              MyText(title: "Taimoor Sikander", size: 22,fontWeight: FontWeight.bold, color: Colors.white)
            ],
          ),
          IconButton(onPressed: hanlder, icon: Icon(Iconsax.shopping_bag,size: 30, color: Colors.white,))
        ],
      ),
    );
  }
}
