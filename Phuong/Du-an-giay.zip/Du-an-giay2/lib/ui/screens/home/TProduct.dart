import 'package:coffee_shop_test/data/models/product.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import '../../shared/constants/my_list.dart';
import '../../shared/widget/container_vorcher.dart';
import '../../shared/widget/my_image.dart';
import '../../shared/widget/my_text.dart';
import '../product_detail/product_detail.dart';

class Tproduct extends StatefulWidget {
  final product;
  final String token;
  final int user_id;
  const Tproduct({super.key, required this.product, required this.token, required this.user_id});
  @override
  State<Tproduct> createState() => _TproductState();
}

class _TproductState extends State<Tproduct> {
  bool isCheck = false;
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      itemCount: widget.product["data"].length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisExtent: 320
      ),
      itemBuilder: (context, index) {
        final item = widget.product["data"][index];
        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ProductDetail(
                  product_id: item["id"],
                  productData: item,
                  token: widget.token, user_id: widget.user_id,
                ),
              ),
            );
          },
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: Colors.grey.withOpacity(0.1),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TContainerVorcher(
                        height: 30,
                        width: 40,
                        colorContainer: Colors.yellow,
                        radiuseContainer: 5,
                        child:  Center(
                          child: MyText(
                            title: "78%",
                            size: 15,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                      Container(
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                          color: Colors.white.withOpacity(0.8),
                        ),
                        child: IconButton(
                          onPressed: () {
                            setState(() {
                              isCheck = !isCheck;
                            });
                          },
                          icon: Icon(
                            Iconsax.heart,
                            size: 24,
                            color: isCheck ? Colors.red : Colors.black,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Product Image (bỏ padding thừa)
                Expanded(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Image.network(
                        height: 150,
                        "http://10.0.2.2:8989/api/images/${item["image"]}",
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                ),
                // Product info
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      MyText(
                        title: "${item["name"]}",
                        size: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black45,
                      ),
                      MyText(
                        title: "Nike",
                        size: 14,
                        color: Colors.grey,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          MyText(
                            title: "122.6-334.0",
                            size: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(12),
                                bottomRight: Radius.circular(12),
                              ),
                              color: Colors.blueAccent,
                            ),
                            child: const Center(
                              child: MyText(
                                title: "1",
                                size: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/**/
