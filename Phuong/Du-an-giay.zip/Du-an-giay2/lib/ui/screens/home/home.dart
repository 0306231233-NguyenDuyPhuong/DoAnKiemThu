import 'package:coffee_shop_test/data/viewmodels/home_viewmodels.dart';
import 'package:coffee_shop_test/data/viewmodels/product_viewmodels.dart';
import 'package:coffee_shop_test/ui/screens/home/widgets/SearchScreen.dart';
import 'package:coffee_shop_test/ui/screens/home/widgets/TProduct.dart';
import 'package:coffee_shop_test/ui/screens/home/widgets/body_search.dart';
import 'package:flutter/material.dart';
import '../../shared/constants/list_category.dart';
import '../../shared/widget/container_bottom.dart';
import 'widgets/TBanner.dart';
import 'widgets/TTitleProduct.dart';
import 'widgets/appbar_title.dart';
import '../../shared/widget/TCirlerContainer.dart';
import '../cart/cart.dart';
import 'widgets/body_title_category.dart';

class Home extends StatefulWidget {
  final String token;
  const Home({super.key, required this.token});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late Future<Map<String, dynamic>> fechAllDataHome;
  late Future<Map<String, dynamic>> fechAllProducts;
  HomeViewModel homeViewModel = HomeViewModel();
  ProductViewModel productViewModel = ProductViewModel();
  int category_id = -1;

  @override
  void initState(){
    // TODO: implement initState
    super.initState();
    fechAllDataHome = homeViewModel.fechAllDataHome(widget.token, category_id);
    fechAllProducts = productViewModel.getProduct(widget.token, category_id);
  }

  Widget build(BuildContext context) {
    TextEditingController txtSearchController = TextEditingController();
    late int user_id;

    return Scaffold(
      body: FutureBuilder(
        future: fechAllDataHome,
        builder: (context, snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.waiting:
              return Center(child: CircularProgressIndicator());
            case ConnectionState.none:
            // TODO: Handle this case.
              throw UnimplementedError();
            case ConnectionState.active:
            // TODO: Handle this case.
              throw UnimplementedError();
            case ConnectionState.done:
              if (snapshot.hasError) {
                return Center(child: Text("${snapshot.error}"));
              }
              final user = snapshot.data!["users"]["user"]["data"];
              user_id = user["id"];
              final category = snapshot.data!["categories"]["category"];
              final banner = snapshot.data!["banners"]["banner"];
              final wish = snapshot.data!["wishs"];

              return Stack(
                children: [
                  TCirlerContainer(height: 400, width: 500),
                  Column(
                    children: [
                      // ===== PHẦN CỐ ĐỊNH =====
                      TTitle(
                        hanlder: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => CartView(
                                user_id: user_id,
                                token: widget.token,
                              ),
                            ),
                          );
                        },
                      ),

                      const SizedBox(height: 16),

                      TSearch(
                        color: Colors.white,
                        controller: txtSearchController,
                        handler: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SearchScreen(
                                data_search: '',
                                handler: (String p1) {},
                              ),
                            ),
                          );
                        },
                      ),

                      const SizedBox(height: 16),

                      // ===== PHẦN CUỘN =====
                      Expanded(
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              const TTitleCategory(),
                              const SizedBox(height: 16),
                              Container(
                                height: 80,
                                child: TListCategory(
                                  categoryData: category,
                                  category_id: category_id,
                                  handler: (int value) {
                                    setState(() {
                                      category_id = value;
                                      fechAllProducts = productViewModel.getProduct(
                                        widget.token,
                                        value,
                                      );
                                    });
                                  },
                                ),
                              ),

                              Padding(
                                padding: const EdgeInsets.only(top: 10),
                                child: Container(
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(20),
                                      topRight: Radius.circular(20),
                                    ),
                                    color: Colors.white,
                                  ),
                                  child: Column(
                                    children: [
                                      const SizedBox(height: 20),

                                      // Banner
                                      Container(
                                        height: 200,
                                        width: 380,
                                        decoration: BoxDecoration(
                                          color: Colors.grey.withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(20),
                                        ),
                                        child: TBanner(bannerData: banner),
                                      ),

                                      const SizedBox(height: 20),
                                      const TTitleProduct(),

                                      Tproduct(
                                        token: widget.token,
                                        user_id: user_id,
                                        wish: wish,
                                        productsFuture: fechAllProducts,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              );
          }
        },
      ),
      bottomNavigationBar: ContainerBottom(token: widget.token),
    );

  }
}
