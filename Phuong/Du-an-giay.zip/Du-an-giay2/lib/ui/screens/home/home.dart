import 'package:coffee_shop_test/data/viewmodels/banner_viewmodels.dart';
import 'package:coffee_shop_test/data/viewmodels/category_viewmodels.dart';
import 'package:coffee_shop_test/data/viewmodels/product_viewmodels.dart';
import 'package:coffee_shop_test/data/viewmodels/user_viewmodels.dart';
import 'package:coffee_shop_test/ui/screens/home/widgets/TProduct.dart';
import 'package:coffee_shop_test/ui/screens/home/widgets/body_search.dart';
import 'package:coffee_shop_test/ui/screens/user/user.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import '../../shared/constants/list_category.dart';
import '../../shared/widget/container_bottom.dart';
import 'widgets/TBanner.dart';
import 'widgets/TBottomNavigation.dart';
import 'widgets/TTitleProduct.dart';
import 'widgets/appbar_title.dart';
import '../../shared/widget/TCirlerContainer.dart';
import '../cart/cart.dart';
import 'widgets/body_title_category.dart';

class Home extends StatefulWidget {
  final String token;
  const Home({super.key, required this.token});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    //API cần load
    CategoryViewModel categoryViewModel = CategoryViewModel();
    BannerViewModel bannerViewModel = BannerViewModel();
    ProductViewModel productViewModel = ProductViewModel();
    UserViewModel userViewModel = UserViewModel();

    TextEditingController txtSearchController = TextEditingController();
    late int user_id;

    Future<Map<String, dynamic>> fechAllDataHome() async {
      final results = await Future.wait([
        userViewModel.userProfile(widget.token),
        categoryViewModel.getCategories(widget.token),
        bannerViewModel.getCategories(widget.token),
        productViewModel.getProduct(widget.token),
      ]);
      return {
        'users': results[0],
        'categories': results[1],
        'banners': results[2],
        'products': results[3],
      };
    }

    return Scaffold(
      body: FutureBuilder(
          future: fechAllDataHome(),
          builder: (context, snapshot) {
            switch (snapshot.connectionState) {
              case ConnectionState.none:
                // TODO: Handle this case.
                throw UnimplementedError();
              case ConnectionState.waiting:
                return Center(child: CircularProgressIndicator());
              case ConnectionState.active:
                // TODO: Handle this case.
                throw UnimplementedError();
              case ConnectionState.done:
                if (snapshot.hasError) {
                  return Center(child: Text("${snapshot.error}"));
                }

                final user = snapshot.data!["users"]["user"]["data"];
                user_id = user["id"];
                final category = snapshot.data!["categories"]["category"];
                final banner = snapshot.data!["banners"]["banner"];
                final product = snapshot.data!["products"]["product"];

                return Column(
                  children: [
                    // Vùng Stack phía trên
                    Stack(
                      children: [
                        TCirlerContainer(height: 400, width: 500),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            TTitle(
                              hanlder: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => Cart(user_id: user_id, token: widget.token,),
                                  ),
                                );
                              },
                            ),
                            // Ô tìm kiếm
                            const SizedBox(height: 16),

                            TSearch(
                              color: Colors.white,
                              controller: txtSearchController,
                              handler: () {},
                            ),
                            const SizedBox(height: 16),

                            // Tiêu đề “Popular Categories”
                            const TTitleCategory(),
                            const SizedBox(height: 16),
                            Container(
                              height: 80,
                              child: TListCategory(categoryData: category,),
                            ),

                            //Vùng banner và sản phẩm
                           Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Container(
                                width: 430,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20),
                                  ),
                                  color: Colors.white,
                                ),
                                child: Column(
                                  children: [
                                    Container(
                                        height: 200,
                                        width: 370,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(15),
                                          color: Colors.grey.withOpacity(0.2),
                                        ),
                                        child: TBanner(bannerData: banner,)
                                    ),

                                    const SizedBox(height: 20,),
                                    const TTitleProduct(),
                                    Container(
                                      height: 280,
                                      width: 400,
                                      decoration: BoxDecoration(
                                      ),
                                      child: Tproduct(product: product, token: widget.token, user_id: user_id,),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                );
            }
          },
        ),
      bottomNavigationBar: ContainerBottom(token: widget.token),
    );
  }
}
