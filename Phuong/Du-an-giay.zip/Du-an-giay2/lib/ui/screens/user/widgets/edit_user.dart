import 'package:coffee_shop_test/data/models/user.dart';
import 'package:coffee_shop_test/data/viewmodels/user_viewmodels.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

class EditUser extends StatefulWidget {
  final String token;
  final userDataLoad;
  const EditUser({super.key, required this.token, required this.userDataLoad});

  @override
  State<EditUser> createState() => _EditUserState();
}

class _EditUserState extends State<EditUser> {
  UserViewModel userViewModel = UserViewModel();
  final txtNameController = TextEditingController();
  var userData;


  @override
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    userData = widget.userDataLoad;
  }
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Change Name",
          style: const TextStyle(
            fontSize: 30,
            color: Colors.black87,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Column(
        children: [
          Container(
            height: 200,
            decoration: BoxDecoration(),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 80,
                    width: 80,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(400),
                    ),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: Text(
                      "Change Profile Pricture",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const Divider(
            color: Colors.grey,
            thickness: 2,
            indent: 16,
            endIndent: 16,
          ),
          Container(
            height: 200,
            padding: EdgeInsets.only(left: 16, right: 16, top: 20),
            decoration: BoxDecoration(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Profile Information",
                  style: const TextStyle(
                    fontSize: 25,
                    color: Colors.black87,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Name",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "${userData["name"]}",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        showDialog(context: context, builder: (context){
                          return AlertDialog(
                            title: Text("Edit name user"),
                            content: TextField(
                              decoration: InputDecoration(
                                border: OutlineInputBorder()
                              ),
                              controller: txtNameController,
                            ),
                            actions: [
                              Row(
                                children: [
                                  ElevatedButton(onPressed: (){
                                    Navigator.pop(context);

                                  }, child: Text("Exit")),
                                  ElevatedButton(onPressed: ()async{
                                    final user = User(
                                        id: userData['id'],
                                        email: userData['email'],      // giữ email cũ
                                        password: userData['password'],// giữ password cũ
                                        name: txtNameController.text,  // update name
                                        role: userData['role'],
                                        avatar: userData['avatar'],    // giữ avatar cũ
                                        phone: userData['phone'],
                                        status: userData['status'],
                                        email_verified: userData['email_verified']
                                    );
                                    final result = await userViewModel.putUserUpdate(userData['id'],widget.token, user);
                                      Navigator.pop(context);
                                    final userDataUpdate = await userViewModel.userProfile(widget.token);
                                    setState(() {
                                      userData = userDataUpdate;
                                    });
                                    print(userData);
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(content: Text("Cập nhật thành công!")),
                                    );

                                  }, child: Text("Edit"))
                                ],
                              )
                            ],
                          );
                        });
                      },
                      icon: Icon(
                        Iconsax.arrow_right_3,
                        size: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "User name",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "${userData["name"]}",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Iconsax.arrow_right_3,
                        size: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const Divider(
            color: Colors.grey,
            thickness: 2,
            indent: 16,
            endIndent: 16,
          ),
          Container(
            padding: EdgeInsets.only(left: 16, right: 16, top: 20),
            decoration: BoxDecoration(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      "Personal Information",
                      style: const TextStyle(
                        fontSize: 25,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "UserId",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "${userData["id"]}",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Iconsax.copy,
                        size: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "User name",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "${userData["name"]}",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Iconsax.arrow_right_3,
                        size: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "E-mail",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "${userData["email"]}",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Iconsax.arrow_right_3,
                        size: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Phone Number",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "${userData["phone"]}",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Iconsax.arrow_right_3,
                        size: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Gender",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "${userData["Gender"]}",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Iconsax.arrow_right_3,
                        size: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Date of Birth",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "${userData["Gender"]}",
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Iconsax.arrow_right_3,
                        size: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const Divider(
            color: Colors.grey,
            thickness: 2,
            indent: 16,
            endIndent: 16,
          ),
          const SizedBox(height: 30),
          Text(
            "Close Account",
            style: const TextStyle(fontSize: 15, color: Colors.red),
          ),
        ],
      ),
    );
  }
}
