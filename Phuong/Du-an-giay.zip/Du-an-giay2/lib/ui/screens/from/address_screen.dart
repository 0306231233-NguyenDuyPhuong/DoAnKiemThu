import 'package:flutter/material.dart';
class AddressScreen extends StatefulWidget {
  final String token;
  const AddressScreen({super.key, required this.token});

  @override
  State<AddressScreen> createState() => _AddressScreenState();
}

class _AddressScreenState extends State<AddressScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text("${widget.token}"),
      ),
    );
  }
}
