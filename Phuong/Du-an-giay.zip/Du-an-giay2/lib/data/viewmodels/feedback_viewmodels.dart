import 'package:coffee_shop_test/data/services/feedback_service.dart';

class CategoryViewModel {
  final FeedbackService _feedbackService = FeedbackService();

  Future<Map<String, dynamic>> getCategories(String token, int product_id) async {
    final data = await _feedbackService.getFeedBacks(token, product_id);
    return {
      "feedbacks": data
    };
  }
}