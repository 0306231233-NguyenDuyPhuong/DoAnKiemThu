import 'package:coffee_shop_test/data/models/user.dart';
import 'package:coffee_shop_test/data/services/user_service.dart';

class UserViewModel{
  UserService userService = UserService();

  Future<Map<String, dynamic>> userProfile(String token)async{
    final data =await userService.getUserProfile(token);
    return {
      "user":data
    };
  }
  Future<Map<String, dynamic>> userLogin(User user)async{
    final data =await userService.PostUserLogin(user);
    return {
      "login":data
    };
  }
}