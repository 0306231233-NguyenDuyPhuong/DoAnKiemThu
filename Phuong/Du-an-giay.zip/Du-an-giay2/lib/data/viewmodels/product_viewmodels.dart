import 'package:coffee_shop_test/data/models/product.dart';
import 'package:coffee_shop_test/data/services/product_service.dart';

class ProductViewModel{
  ProductService _productService = ProductService();
  List<Product> productList = [];
  Product? selectedProdcut;

  Future<Map<String, dynamic>> getProduct(String token)async{
    final data =await _productService.getProduct(token);
    return {
      "product":data
    };
  }

  Future<Product?> getProductById(int id)async{
    try{
      selectedProdcut = await _productService.getProductById(id);
      return selectedProdcut;
    }catch(e){
      throw Exception(e);
    }
  }
}