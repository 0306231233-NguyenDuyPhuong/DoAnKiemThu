class Feedback {
  final int id;
  final int product_id;
  final int user_id;
  final int star;
  final String content;
  final String created_at;
  final String updated_at;

  Feedback({
    required this.id,
    required this.product_id,
    required this.user_id,
    required this.star,
    required this.content,
    required this.created_at,
    required this.updated_at,
  });

  factory Feedback.fromJson(Map<String, dynamic> json) {
    return Feedback(
      id: json['id'],
      product_id: json['product_id'],
      user_id: json['user_id'],
      star: json['star'],
      content: json['content'],
      created_at: json['created_at'],
      updated_at: json['updated_at'],
    );
  }
}
