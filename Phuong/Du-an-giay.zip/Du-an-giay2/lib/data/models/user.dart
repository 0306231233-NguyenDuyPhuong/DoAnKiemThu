class User {
  final int id;
  final String email;
  final String password;
  final String name;
  final int role;
  final String avatar;
  final String phone;
  final int status;
  final bool email_verified;

  User({
    required this.id,
    required this.email,
    required this.password,
    required this.name,
    required this.role,
    required this.avatar,
    required this.phone,
    required this.status,
    required this.email_verified,

  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] ?? 0,
      email: json['email']?.toString() ?? '',
      password: json['password']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      role: json['role'] ?? 0,
      avatar: json['avatar']?.toString() ?? '',
      phone: json['phone']?.toString() ?? '',
      status: json['status'] ?? 0,
      email_verified: json['email_verified'] ?? false,
    );
  }

  Map<String, dynamic> toLogin(){
    return {
      'phone':phone,
      'password':password
    };
  }

  Map<String, dynamic> toJson(){
    return {
      'email':email,
      'password':password,
      'name':name,
      'role':role,
      'avatar':avatar,
      'phone':phone,
      'status':status,
      'email_verified':email_verified
    };
  }

  Map<String, dynamic> toUpdate(){
    return {
      "name":name
    };
  }
}
