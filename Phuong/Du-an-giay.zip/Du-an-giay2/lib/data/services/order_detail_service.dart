import 'dart:convert';

import 'package:coffee_shop_test/data/models/order_detail.dart';
import 'package:coffee_shop_test/data/services/baseurl.dart';
import 'package:http/http.dart' as http;
class OrderDetailService{
  Future<List<OrderDetail>> getAllOrderDetail() async{
    try{
      final response = await http.get(Uri.parse("${BaseUrl.baseUrl}order-details"));
      if(response.statusCode == 200){
        final data = jsonDecode(response.body)['data'];
        return (data as List).map((e)=>OrderDetail.fromJson(e)).toList();
      }else{
        throw Exception("Lỗi khi tải Order detail");
      }
    }catch(e){
      throw Exception(e);
    }
  }
}