class BaseUrl {
  static const String baseUrl = "http://10.0.2.2:8989/api/";
}