

import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/user.dart';
import 'baseurl.dart';

class UserService {
  Future<Map<String, dynamic>> getUserProfile(String token) async {
    try {
      final url = Uri.parse("${BaseUrl.baseUrl}users/profile");
      final res = await http.get(
          url,
          headers: {"Authorization":"Bearer $token"},
      );
      final data = jsonDecode(res.body)["data"];
      if(res.statusCode == 200){
        return{
          "data":data
        };
      }
      else{
        return{
          "message":data["message"]
        };
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  Future<Map<String, dynamic>> PostUserLogin(User user) async {
    try {
      final url = Uri.parse("${BaseUrl.baseUrl}users/login");
      final res = await http.post(
          url,
          headers: {"Content-Type":"application/json"},
          body: jsonEncode(user.toLogin())
      );
      final data = jsonDecode(res.body)["data"];
      if(res.statusCode == 200){
        return{
          "status":res.statusCode,
          "token":data["token"]
        };
      }
      else{
        return{
          "status":res.statusCode
        };
      }
    } catch (e) {
      throw Exception(e);
    }
  }
}

