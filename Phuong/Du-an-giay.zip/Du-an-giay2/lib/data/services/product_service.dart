import 'dart:convert';

import 'package:coffee_shop_test/data/models/product.dart';
import 'package:coffee_shop_test/data/services/baseurl.dart';
import 'package:http/http.dart' as http;

class ProductService{
  Future<Map<String, dynamic>> getProduct(String token) async {
    try {
      final url = Uri.parse("${BaseUrl.baseUrl}products");
      final res = await http.get(
        url,
        headers: {"Authorization":"Bearer $token"},
      );
      final data = jsonDecode(res.body)["data"];
      if(res.statusCode == 200){
        return{
          "data":data
        };
      }
      else{
        return{
          "message":data["message"]
        };
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  Future<Product> getProductById(int id) async{
    try{
      final response = await http.get(Uri.parse("${BaseUrl.baseUrl}products"));
      if(response.statusCode == 200){
        final data = jsonDecode(response.body)['data'];
        return Product.fromJson(data);
      }else{
        throw Exception("Lỗi khi tải product");
      }
    }catch(e){
      throw Exception(e);
    }
  }
}