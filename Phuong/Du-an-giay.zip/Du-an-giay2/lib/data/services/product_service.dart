import 'dart:convert';

import 'package:coffee_shop_test/data/models/product.dart';
import 'package:coffee_shop_test/data/services/baseurl.dart';
import 'package:http/http.dart' as http;

class ProductService{
  Future<Map<String, dynamic>> getProduct(String token, int? category_id) async {
    try {
      String base = "${BaseUrl.baseUrl}products?";
      if(category_id != -1){
        base = "${BaseUrl.baseUrl}products?category_id=${category_id}";
      }
      final url = Uri.parse(base);
      final res = await http.get(
        url,
        headers: {"Authorization":"Bearer $token"},
      );
      final data = jsonDecode(res.body)["data"];
      if(res.statusCode == 200){
        return{
          "data":data
        };
      }
      else{
        return{
          "message":data["message"]
        };
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  Future<Map<String, dynamic>> getProductById(String token, int id) async {
    try {
      String base = "${BaseUrl.baseUrl}products/$id";
      final url = Uri.parse(base);
      final res = await http.get(
        url,
        headers: {"Authorization":"Bearer $token"},
      );
      final data = jsonDecode(res.body)["data"];
      if(res.statusCode == 200){
        return{
          "data":data
        };
      }
      else{
        return{
          "message":data
        };
      }
    } catch (e) {
      throw Exception(e);
    }
  }
}