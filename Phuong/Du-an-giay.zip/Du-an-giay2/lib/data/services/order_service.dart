import 'dart:convert';

import 'package:coffee_shop_test/data/models/category.dart';
import 'package:coffee_shop_test/data/models/order.dart';
import 'package:coffee_shop_test/data/services/baseurl.dart';
import 'package:http/http.dart' as http;
class OrderService{
  Future<List<Order>> getAllOrder()async{
    try {
      final response = await http.get(Uri.parse("${BaseUrl.baseUrl}orders"));
      if(response.statusCode == 200){
        final data = jsonDecode(response.body)['data'];
        return (data as List).map((e)=>Order.fromJson(e)).toList();
      }else{
        throw Exception("Lỗi tải order");
      }
    }catch(e){
      throw Exception(e);
    }
  }
}