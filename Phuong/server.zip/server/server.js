import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import db from "./db.js";

const app = express();
app.use(cors());
app.use(bodyParser.json());

const SECRET_KEY = "your_secret_key"; // JWT secret

// 🟢 Đăng ký (Register)
app.post("/api/user/register", async (req, res) => {
  const { fullname, username, password, gender, dob } = req.body;

  if (!fullname || !username || !password) {
    return res.status(400).json({ message: "Vui lòng nhập đầy đủ thông tin" });
  }

  db.query("SELECT * FROM users WHERE username = ?", [username], async (err, result) => {
    if (err) return res.status(500).json({ message: "Lỗi server" });
    if (result.length > 0) return res.status(400).json({ message: "Tên đăng nhập đã tồn tại" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const now = new Date();

    const sql = `
      INSERT INTO users (fullname, username, password, gender, dob, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    db.query(sql, [fullname, username, hashedPassword, gender, dob, now, now], (err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: "Không thể tạo tài khoản" });
      }
      res.json({ 
        success:true,
        message: "Đăng ký thành công!" });
    });
  });
});

// 🟢 Đăng nhập (Login)
app.post("/api/user/login", (req, res) => {
  const { username, password } = req.body;
  console.log(username, password)
  db.query("SELECT * FROM users WHERE username = ? AND deleted_at IS NULL", [username], async (err, result) => {
    if (err) return res.status(500).json({ message: "Lỗi server" });
    if (result.length === 0) return res.status(400).json({ message: "Sai tài khoản hoặc mật khẩu" });

    const user = result[0];
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: "Sai mật khẩu" });

    const token = jwt.sign(
      { id: user.id, username: user.username },
      SECRET_KEY,
      { expiresIn: "1h" }
    );

    res.json({
      success: true,
      token,
    });
  });
});
// Middleware kiểm tra token
function verifyToken(req, res, next) {
  const authHeader = req.headers["authorization"];
  if (!authHeader) return res.status(401).json({ success: false, message: "Không có token" });

  const token = authHeader.split(" ")[1]; // Bearer token
  if (!token) return res.status(401).json({ success: false, message: "Token không hợp lệ" });

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) return res.status(403).json({ success: false, message: "Token không hợp lệ" });
    req.user = user;
    next();
  });
}

// Lấy thông tin user dựa vào token
app.get("/api/user/profile", verifyToken, (req, res) => {
  const userId = req.user.id;
  db.query("SELECT id, fullname, username, gender, dob FROM users WHERE id = ? AND deleted_at IS NULL", [userId], (err, result) => {
    if (err) return res.status(500).json({ success: false, message: "Lỗi server" });
    if (result.length === 0) return res.status(404).json({ success: false, message: "User không tồn tại" });
    res.json({ success: true, user: result[0] });
  });
});


// Lấy toàn bộ sản phẩm
app.get("/api/products", verifyToken,(req, res) => {
  db.query("SELECT * FROM products WHERE deleted_at IS NULL", (err, result) => {
    if (err) return res.status(500).json({ message: "Lỗi server" });
    return res.json({ success: true, products: result });
  });
});


// Thêm sản phẩm vào giỏ hàng
app.post("/api/cart", verifyToken, (req, res) => {
  const userId = req.user.id;
  const { product_id, quantity } = req.body;

  if (!product_id || !quantity) {
    return res.status(400).json({ message: "Thiếu product_id hoặc quantity" });
  }

  // Kiểm tra sản phẩm đã tồn tại trong giỏ hay chưa
  const checkSql = "SELECT * FROM cart WHERE user_id = ? AND product_id = ?";
  db.query(checkSql, [userId, product_id], (err, result) => {
    if (err) return res.status(500).json({ message: "Lỗi server" });

    if (result.length > 0) {
      // Nếu đã có → tăng số lượng
      const newQty = result[0].quantity + quantity;
      db.query(
        "UPDATE cart SET quantity = ?, updated_at = NOW() WHERE id = ?",
        [newQty, result[0].id],
        () => res.json({ success: true, message: "Đã cập nhật giỏ hàng" })
      );
    } else {
      // Nếu chưa → thêm mới
      db.query(
        "INSERT INTO cart (user_id, product_id, quantity, created_at) VALUES (?, ?, ?, NOW())",
        [userId, product_id, quantity],
        () => res.json({ success: true, message: "Đã thêm vào giỏ hàng" })
      );
    }
  });
});



app.get("/api/cart", verifyToken, (req, res) => {
  const userId = req.user.id;

  const sql = `
    SELECT c.id, c.quantity, p.name, p.price, p.thumbnail
    FROM cart c
    JOIN products p ON c.product_id = p.id
    WHERE c.user_id = ?
  `;

  db.query(sql, [userId], (err, result) => {
    if (err) return res.status(500).json({ message: "Lỗi server" });
    res.json({ success: true, cart: result });
  });
});


app.post("/api/order", verifyToken, (req, res) => {
  const userId = req.user.id;

  const sqlCart = `
    SELECT c.product_id, c.quantity, p.price
    FROM cart c
    JOIN products p ON c.product_id = p.id
    WHERE c.user_id = ?
  `;

  db.query(sqlCart, [userId], (err, cartItems) => {
    if (err) return res.status(500).json({ message: "Lỗi server" });
    if (cartItems.length === 0) return res.status(400).json({ message: "Giỏ hàng trống" });

    // Tính tổng tiền
    let total = 0;
    cartItems.forEach(item => {
      total += item.price * item.quantity;
    });

    // Tạo order
    db.query(
      "INSERT INTO orders (user_id, total_price, created_at) VALUES (?, ?, NOW())",
      [userId, total],
      (err, orderResult) => {
        if (err) return res.status(500).json({ message: "Không thể tạo đơn hàng" });

        const orderId = orderResult.insertId;

        // Tạo danh sách order_items
        const orderItemsData = cartItems.map(item => [
          orderId,
          item.product_id,
          item.price,
          item.quantity
        ]);

        db.query(
          "INSERT INTO order_items (order_id, product_id, price, quantity) VALUES ?",
          [orderItemsData],
          (err) => {
            if (err) return res.status(500).json({ message: "Không thể tạo order items" });

            // Xóa giỏ hàng
            db.query("DELETE FROM cart WHERE user_id = ?", [userId]);

            return res.json({
              success: true,
              message: "Đặt hàng thành công!",
              order_id: orderId,
            });
          }
        );
      }
    );
  });
});

// ✅ Chạy server
app.listen(3000, () => {
  console.log("🚀 Server đang chạy tại http://localhost:3000");
});
