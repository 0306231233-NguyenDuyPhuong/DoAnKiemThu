import 'dart:ui';

class AppColor {
  // Background pastel (hồng tím nhẹ)
  static Color kBackground = Color(0xFFF8E6F8); // #F8E6F8

  // Card / Surface (white)
  static Color kCard = Color(0xFFFFFFFF); // #FFFFFF

  // Primary gradient (purple) - start / end
  static Color kPrimaryPurpleStart = Color(0xFF7C4DFF); // #7C4DFF
  static Color kPrimaryPurpleEnd = Color(0xFFA855FF); // #A855FF

  // Accent blue (slider / small accents)
  static Color kAccentBlue = Color(0xFF4DA3FF); // #4DA3FF

  // Light ring / subtle background inside cards
  static Color kLightLavender = Color(0xFFEFF4FF); // #EFF4FF

  // Primary text (dark)
  static Color kTextPrimary = Color(0xFF111827); // #111827

  // Neutrals / border
  static Color kBorder = Color(0xFFE6E9EE); // #E6E9EE

  // LED indicator yellow
  static Color kLedYellow = Color(0xFFFFC857); // #FFC857
}
