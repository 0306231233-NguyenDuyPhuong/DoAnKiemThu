import 'package:app_bai_tap_lop/widgets/app_colors.dart';
import 'package:flutter/material.dart';

class ContainerLed extends StatelessWidget {
  const ContainerLed({
    super.key,
    required this.title,
    required this.color,
  });
  final String title;
  final Color color;
  final double? height = 180;
  final double? width = 170;
  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      padding: EdgeInsets.all(15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white,
        border: Border.all(
          color: AppColor.kPrimaryPurpleEnd,
          width: 1)
      ),
      child: Column(
        children: [
          Icon(Icons.lightbulb_outlined, size: 100, color: AppColor.kPrimaryPurpleEnd,),
          const SizedBox(height: 10),
          Text(
            title,
            style: TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.bold,
              color: AppColor.kPrimaryPurpleStart,
            ),
          ),
        ],
      ),
    );
  }
}
