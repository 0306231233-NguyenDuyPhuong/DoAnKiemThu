class Led {
  final bool group_1;
  final bool group_2;
  final bool group_3;
  final bool group_4;
  final int led;
  final int speed_1;
  final int speed_2;
  final int speed_3;
  final int speed_4;

  Led({
    required this.group_1,
    required this.group_2,
    required this.group_3,
    required this.group_4,
    required this.led,
    required this.speed_1,
    required this.speed_2,
    required this.speed_3,
    required this.speed_4,
  });

  factory Led.fromJson(Map<String, dynamic> json) {
    return Led(
      group_1: json['group_1'],
      group_2: json['group_2'],
      group_3: json['group_3'],
      group_4: json['group_4'],
      led: json['led'],
      speed_1: json['speed_1'],
      speed_2: json['speed_2'],
      speed_3: json['speed_3'],
      speed_4: json['speed_4'],
    );
  }
  Map<String, dynamic> toJson() {
    return {
      'group_1': group_1,
      'group_2': group_2,
      'group_3': group_3,
      'group_4': group_4,
      'led': led,
      'speed_1': speed_1,
      'speed_2': speed_2,
      'speed_3': speed_3,
      'speed_4': speed_4,
    };
  }
}
