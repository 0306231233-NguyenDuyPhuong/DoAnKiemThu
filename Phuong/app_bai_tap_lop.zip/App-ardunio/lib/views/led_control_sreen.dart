import 'dart:math';

import 'package:app_bai_tap_lop/widgets/app_colors.dart';
import 'package:app_bai_tap_lop/widgets/container_circler.dart';
import 'package:app_bai_tap_lop/widgets/container_switch.dart';
import 'package:flutter/material.dart';
import 'package:sleek_circular_slider/sleek_circular_slider.dart';

class LedControlSreen extends StatefulWidget {
  final int id;
  final String name;
  const LedControlSreen({super.key, required this.id, required this.name});

  @override
  State<LedControlSreen> createState() => _LedControlSreenState();
}

class _LedControlSreenState extends State<LedControlSreen> {
  double brightnessValue = 50;
  double speedValue = 50;
  bool isControlGroupLed = false;
  bool isSpeedLed = false;
  bool isBrightnessLed = false;
  double maxValue=225;
  final listLed = [1,2,3,4,5,6,7,8];
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Center(child: Text(
        "${widget.name}",
        style: TextStyle(
          fontSize: 30,
          color: AppColor.kPrimaryPurpleStart,
          fontWeight: FontWeight.bold,
        ),
      ),)),
      body: Padding(
        padding: const EdgeInsets.only(top: 30, right: 16, left: 16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ContainerSwitch(
                  child: GridView.count(crossAxisCount: 4,
                  children: listLed.map((item){
                    return Container(
                      width: 40,
                      height: 40,
                      margin: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(400),
                          color: AppColor.kPrimaryPurpleEnd.withOpacity(0.1)
                      ),
                      child: Center(
                        child: Icon(Icons.lightbulb_rounded, color: AppColor.kLedYellow,),
                      ),
                    );
                  }).toList()
                  )
                ),

                ContainerSwitch(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Switch(
                          value: isControlGroupLed,
                          activeColor: AppColor.kPrimaryPurpleStart,
                          trackOutlineColor: MaterialStateProperty.all(
                            Colors.white,
                          ),
                          inactiveTrackColor: AppColor.kPrimaryPurpleStart
                              .withOpacity(0.1),
                          inactiveThumbColor: AppColor.kPrimaryPurpleStart,
                          onChanged: (bool value) {
                            setState(() {
                              isControlGroupLed = value;
                            });
                          },
                        ),
                        Text(
                          "Turn Off/On group led",
                          style: TextStyle(
                            fontSize: 18,
                            color: AppColor.kPrimaryPurpleStart,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 80),
            ContainerCircler(
              initialValue: brightnessValue,
              max: maxValue,
              title: isSpeedLed?"Speed": isBrightnessLed? "Brightness":"",
            ),
            const SizedBox(height: 80),
            Container(
              height: 170,
              width: 400,
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                border: Border.all(
                  color: AppColor.kPrimaryPurpleStart.withOpacity(0.5)
                ),
                borderRadius: BorderRadius.circular(20)
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      //Speed
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isSpeedLed = !isSpeedLed;
                            isBrightnessLed = false;
                            isControlGroupLed = false;
                            maxValue = 225;
                          });
                        },
                        child: Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(400),
                            color: AppColor.kAccentBlue,
                          ),
                          child: Center(
                            child: Container(
                              height: 33,
                              width: 33,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(400),
                                color: isSpeedLed?Colors.white:AppColor.kAccentBlue,
                              ),
                            ),
                          ),
                        ),
                      ),

                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isBrightnessLed = !isBrightnessLed;
                            isSpeedLed = false;
                            isControlGroupLed = false;
                            maxValue = 100;
                          });
                        },
                        child: Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(400),
                            color: AppColor.kPrimaryPurpleStart,
                          ),
                          child: Center(
                            child: Container(
                              height: 33,
                              width: 33,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(400),
                                color: isBrightnessLed?Colors.white:AppColor.kPrimaryPurpleStart,
                              ),
                            ),
                          ),
                        ),
                      ),

                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isControlGroupLed = !isControlGroupLed;
                            isBrightnessLed = false;
                            isSpeedLed = false;
                          });
                        },
                        child: Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(400),
                            color: AppColor.kPrimaryPurpleEnd,
                          ),
                          child: Center(
                            child: Container(
                              height: 33,
                              width: 33,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(400),
                                color: isControlGroupLed?Colors.white:AppColor.kPrimaryPurpleEnd,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 30,),
                  Text(
                    isSpeedLed?"Speed": isBrightnessLed? "Brightness":"Turn Off/On group led",
                    style: TextStyle(
                      fontSize: 30,
                      color: AppColor.kPrimaryPurpleStart,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
