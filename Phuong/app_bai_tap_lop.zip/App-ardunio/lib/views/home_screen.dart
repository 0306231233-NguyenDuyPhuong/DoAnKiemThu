import 'package:app_bai_tap_lop/views/led_control_sreen.dart';
import 'package:app_bai_tap_lop/widgets/app_colors.dart';
import 'package:app_bai_tap_lop/widgets/container_bottom.dart';
import 'package:app_bai_tap_lop/widgets/container_chart.dart';
import 'package:app_bai_tap_lop/widgets/container_led.dart';
import 'package:app_bai_tap_lop/widgets/container_switch.dart';
import 'package:flutter/material.dart';

import '../widgets/my_appbar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
   bool isControlLed =false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(padding: EdgeInsets.only(top: 60, left: 16, right: 16),
        child: Column(
          children: [
            MyAppBar(),
            const SizedBox(height: 20,),
            //Chart
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Control LED nhóm", style: const TextStyle(fontSize: 20),),
                Text("Control LED nhóm", style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),)
              ],
            ),
            const SizedBox(height: 20,),
            //Container
            SimpleBarChart(),
            const SizedBox(height: 30,),
            Container(
              height: 150,
              width:400,
              padding: EdgeInsets.all(15),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white,
                  border: Border.all(
                      color: AppColor.kPrimaryPurpleStart
                  )
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(Icons.lightbulb_outlined, size: 60, color: isControlLed? AppColor.kLedYellow:AppColor.kPrimaryPurpleStart,),
                  const SizedBox(height: 10),
                  ContainerSwitch(
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Switch(
                            value: isControlLed,
                            activeColor: AppColor.kPrimaryPurpleStart,
                            trackOutlineColor: MaterialStateProperty.all(
                              Colors.white,
                            ),
                            inactiveTrackColor: AppColor.kPrimaryPurpleStart
                                .withOpacity(0.1),
                            inactiveThumbColor: AppColor.kPrimaryPurpleStart,
                            onChanged: (bool value) {
                              setState(() {
                                isControlLed = value;
                              });
                            },
                          ),
                          Text(
                            "Turn On/Off all led",
                            style: TextStyle(
                              fontSize: 18,
                              color: AppColor.kPrimaryPurpleStart,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            //Container
            const SizedBox(height: 20,),
            Container(
              padding: EdgeInsets.all(15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap:(){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>LedControlSreen(id: 1, name: 'Group led 1',)));
                        },
                          child: ContainerLed(title: "Group led 1", color: Colors.white,)),
                      const SizedBox(width: 20,),
                      GestureDetector(
                          onTap:(){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>LedControlSreen(id: 2, name: 'Group led 2',)));
                          },
                          child: ContainerLed(title: "Group led 2", color: Colors.white)),
                    ],
                  ),
                  const SizedBox(width: 20,height: 20,),
                  Row(
                    children: [
                      GestureDetector(
                          onTap:(){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>LedControlSreen(id: 3, name: 'Group led 3',)));
                          },
                          child: ContainerLed(title: "Group led 3", color: Colors.white,)),
                      const SizedBox(width: 20,),
                      GestureDetector(
                          onTap:(){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>LedControlSreen(id: 4, name: 'Group led 4',)));
                          },
                          child: ContainerLed(title: "Group led 4", color: Colors.white)),
                    ],
                  ),

                ],
              ),
            )

          ],
        ),
        ),
      ),
      bottomNavigationBar: ContainerBottom(),
    );
  }
}
