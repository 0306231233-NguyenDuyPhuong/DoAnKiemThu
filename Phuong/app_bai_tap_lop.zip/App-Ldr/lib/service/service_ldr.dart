import 'package:app_ldr/models/models_ldr.dart';
import 'package:app_ldr/models/models_led.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:rxdart/rxdart.dart';

class CombinedData {
  final LDRModel ldr;
  final LEDModel led;

  CombinedData({required this.ldr, required this.led});
}

class ServiceLdr {
  final _db = FirebaseDatabase.instance.ref();

  Stream<LDRModel> streamLDR() {
    return _db.child("LDR").onValue.map((event) {
      final raw = event.snapshot.value as Map<Object?, Object?>;
      return LDRModel.fromJson(Map<String, dynamic>.from(raw));
    });
  }

  Stream<LEDModel> streamLED() {
    return _db.child("LEDS").onValue.map((event) {
      final raw = event.snapshot.value as Map<Object?, Object?>;
      return LEDModel.fromJson(Map<String, dynamic>.from(raw));
    });
  }

  /// 🔥 Gộp 2 stream thành 1
  Stream<CombinedData> combinedStream() {
    return Rx.combineLatest2(
      streamLDR(),
      streamLED(),
          (LDRModel ldr, LEDModel led) => CombinedData(ldr: ldr, led: led),
    );
  }

  //update led
  void updateLed(String key, bool value) {
    _db.child('LEDS').child(key).set(value);
  }
}
