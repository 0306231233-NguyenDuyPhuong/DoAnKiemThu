class Product {
  final String title;
  final String description;
  final double price;
  final String brand;

  Product({
    required this.title,
    required this.description,
    required this.price,
    required this.brand,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      title: json['title'],
      description: json['description'],
      price: json['price'],
      brand: json['brand'],
    );
  }
  Map<String, dynamic> toJson(){
    return {
      'title':title,
      'description':description,
      'price':price,
      'brand':brand
    };
  }
}
