import 'dart:convert';

import 'package:app_tin_tuc/models/products.dart';
import 'package:http/http.dart' as http;
class ProductViewModel{
  Future<List<Product>> getAllProduct(String url)async{
    try{
      final response = await http.get(Uri.parse(url));
      if(response.statusCode == 200){
        final data = jsonDecode(response.body)['products'] as List;
        return data.map((item)=>Product.fromJson(item)).toList();
      }else{
        throw Exception("Lỗi");
      }
    }catch(e){
      throw Exception(e);
    }
  }
  final baseUrl = Uri.parse("https://dummyjson.com/products/add");
  Future<Map<String, dynamic>> postProducts(Product product)async{
    final response = await http.post(
      baseUrl,
      headers: {"Content-Type":"application/json"},
      body: jsonEncode(product.toJson())
    );
    if(response.statusCode == 201){
      final data = jsonDecode(response.body);
      return {
        "message":true,
        "data":data
      };
    }else{
      return{
        "message":false
      };
    }
  }
}