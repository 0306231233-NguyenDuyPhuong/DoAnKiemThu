import 'dart:convert';

import 'package:app_tin_tuc/models/categories.dart';
import 'package:http/http.dart' as http;
class CategoryViewModel{
  final baseUrl = "https://dummyjson.com/products/categories";
  Future<List<Category>> getAllCategory()async{
    try{
      final response = await http.get(Uri.parse(baseUrl));
      if(response.statusCode == 200){
        final data = jsonDecode(response.body) as List;
        return data.map((item)=>Category.fromJson(item)).toList();
      }else{
        throw Exception("Lỗi");
      }
    }catch(e){
      throw Exception(e);
    }
  }
}