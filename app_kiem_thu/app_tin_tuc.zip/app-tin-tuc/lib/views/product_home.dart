import 'package:app_tin_tuc/viewmodels/product_viewmodels.dart';
import 'package:flutter/material.dart';

import '../models/products.dart';
import '../widgets/my_color.dart';
class ProductHome extends StatefulWidget {
  final String url;
  const ProductHome({super.key, required this.url});

  @override
  State<ProductHome> createState() => _ProductHomeState();
}

class _ProductHomeState extends State<ProductHome> {
  late Future<List<Product>> _fetchProduct;

  ProductViewModel productViewModel = ProductViewModel();

  Future<List<Product>> loadProduct()async{
    return productViewModel.getAllProduct(widget.url);
  }

  @override

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _fetchProduct = loadProduct();
  }
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: Center(
          child: Text(
            "PRODUCTS",
            style: const TextStyle(
              fontSize: 30,
              color: AppColors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
      body: FutureBuilder(future: _fetchProduct, builder: (context, snapshot){
        switch(snapshot.connectionState) {
          case ConnectionState.none:
            // TODO: Handle this case.
            throw UnimplementedError();
          case ConnectionState.waiting:
            return Center(
              child: CircularProgressIndicator(),
            );
          case ConnectionState.active:
            // TODO: Handle this case.
            throw UnimplementedError();
          case ConnectionState.done:
            if(snapshot.hasError){
              return Center(
                child: Text("${snapshot.error}"),
              );
            }
            final data = snapshot.data!;
            return ListView.builder(
                itemCount: data.length,
                itemBuilder: (context, index){
                final item = data[index];
                return Container(
                  margin: EdgeInsets.all(10),
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.primaryLight,
                    borderRadius: BorderRadius.circular(12)
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("${item.title}", style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: AppColors.white),),
                      const SizedBox(height: 10,),
                      Text("${item.description}", style: TextStyle(fontSize: 20, color: AppColors.white),),
                      const SizedBox(height: 10,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("${item.price.toString()}", style: TextStyle(fontSize: 20, color: AppColors.white),),
                          Text("${item.brand}", style: TextStyle(fontSize: 20, color: AppColors.white),),

                        ],
                      )
                    ],
                  ),
                );
            });
        }
      }),
    );
  }
}
