import 'package:app_tin_tuc/models/products.dart';
import 'package:app_tin_tuc/viewmodels/product_viewmodels.dart';
import 'package:flutter/material.dart';

import '../widgets/my_color.dart';

class AddProducts extends StatefulWidget {
  const AddProducts({super.key});

  @override
  State<AddProducts> createState() => _AddProductsState();
}

class _AddProductsState extends State<AddProducts> {
  final txtTitleController = TextEditingController();
  final txtDescriptionController = TextEditingController();
  final txtPriceController = TextEditingController();
  final txtBrandController = TextEditingController();

  ProductViewModel productViewModel = ProductViewModel();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: Center(
          child: Text(
            "Add Product",
            style: const TextStyle(
              fontSize: 30,
              color: AppColors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
      body: Center(
        child: Container(
          height: 500,
          width: 300,
          padding: EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: AppColors.primaryLight,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Title",
                style: TextStyle(fontSize: 20, color: AppColors.white),
              ),
              TextField(
                decoration: InputDecoration(border: OutlineInputBorder()),
                controller: txtTitleController,
              ),
              const Text(
                "Description",
                style: TextStyle(fontSize: 20, color: AppColors.white),
              ),
              TextField(
                decoration: InputDecoration(border: OutlineInputBorder()),
                controller: txtDescriptionController,
              ),
              Text(
                "Price",
                style: TextStyle(fontSize: 20, color: AppColors.white),
              ),
              TextField(
                decoration: InputDecoration(border: OutlineInputBorder()),
                controller: txtPriceController,
              ),
              Text(
                "Brand",
                style: TextStyle(fontSize: 20, color: AppColors.white),
              ),
              TextField(
                decoration: InputDecoration(border: OutlineInputBorder()),
                controller: txtBrandController,
              ),
              ElevatedButton(
                onPressed: () async{
                  final product = Product(
                    title: txtTitleController.text,
                    description: txtDescriptionController.text,
                    price: double.parse(txtPriceController.text.toString()),
                    brand: txtBrandController.text,
                  );

                  final result = await productViewModel.postProducts(product);
                  if(result["message"]){
                    showDialog(context: context, builder: (context)=>
                      AlertDialog(
                        title: Text("Thông báo"),
                        content: Text("Thêm thành công products: ${result['data']}", style: TextStyle(fontSize: 20),),
                      )
                    );
                  }else{
                    showDialog(context: context, builder: (context)=>
                        AlertDialog(
                          title: Text("Thông báo"),
                          content: Text("Thêm thành công products thất bại"),
                        )
                    );
                  }
                },
                child: Center(
                  child: Text(
                    "SAVE",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textDark,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
