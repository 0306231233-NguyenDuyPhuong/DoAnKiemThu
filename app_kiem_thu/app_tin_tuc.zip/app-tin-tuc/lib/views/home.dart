import 'package:app_tin_tuc/views/add_products.dart';
import 'package:app_tin_tuc/views/category_home.dart';
import 'package:app_tin_tuc/widgets/my_color.dart';
import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("SHOPPING NOW", style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: AppColors.textDark),),
            ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>CategoryHome()));
            }, child: Text("Products", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),)),
            ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>AddProducts()));
            }, child: Text("Add news product", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),)),
          ],
        ),
      ),
    );
  }
}
