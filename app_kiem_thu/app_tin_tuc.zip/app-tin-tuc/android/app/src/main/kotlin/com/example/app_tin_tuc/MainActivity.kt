package com.example.app_tin_tuc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
